local map = LazyVim.safe_keymap_set
local opt = { noremap = true, silent = true }
vim.keymap.set("n", "<C-i>", "<Cmd>ToggleTerm<CR>")
vim.keymap.set("n", "<C-n>", vim.cmd.NvimTreeToggle)

map("n", "<C-j>", "15j", opt)
map("n", "<C-k>", "15k", opt)
map("n", "dm", "<Cmd>delmarks!<CR>")

-- telescope
local builtin = require("telescope.builtin")
vim.keymap.set("n", ",s", builtin.find_files, {})
vim.keymap.set("n", ",g", builtin.live_grep, {})
vim.keymap.set("n", ",f", builtin.buffers, {})
vim.keymap.set("n", ",h", builtin.help_tags, {})

-- git
vim.keymap.set("n", "gn", "<Cmd>Gitsigns blame_line<CR>", {})
vim.keymap.set("n", "gl", "<Cmd>Gitsigns blame<CR>", {})

-- lsp
vim.keymap.set("n", "gi", "<Cmd>GoImplements<CR>")
--vim.keymap.set('n', '<C-]>', vim.lsp.buf.references, opts)
vim.keymap.del("n", "<C-]>")
vim.keymap.set("n", "<C-]>", "gd", opt)

-- tagbar
--vim.keymap.del("n", "<C-o>")
--vim.keymap.set("n", "<C-o>", "<cmd>AerialToggle!<CR>")
